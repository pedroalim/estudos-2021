#include<stdio.h>
#include<conio.h>

main(){
    for(int x = 100; x >= 0; x--){
        printf("%i\n", x);
    }

    getch();
}